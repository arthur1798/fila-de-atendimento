﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Queue<Cliente> fila = new Queue<Cliente>();
        int senhaAtual = 1;

        while (true)
        {
            Console.WriteLine("\nOpções:");
            Console.WriteLine("1. Cadastrar cliente");
            Console.WriteLine("2. Listar fila de atendimento");
            Console.WriteLine("3. Atender próximo cliente");
            Console.WriteLine("4. Sair");

            string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    Console.Write("Digite o CPF do cliente: ");
                    string cpf = Console.ReadLine();
                    Console.Write("Digite o nome do cliente: ");
                    string nome = Console.ReadLine();

                    Cliente cliente = new Cliente(cpf, nome, senhaAtual);
                    fila.Enqueue(cliente);
                    Console.WriteLine($"Cliente {nome} cadastrado com senha {senhaAtual}");
                    senhaAtual++;
                    break;

                case "2":
                    Console.WriteLine("Fila de Atendimento:");
                    foreach (Cliente c in fila)
                    {
                        Console.WriteLine($"Senha: {c.Senha}, Nome: {c.Nome}, CPF: {c.CPF}");
                    }
                    break;

                case "3":
                    if (fila.Count > 0)
                    {
                        Cliente clienteAtendido = fila.Dequeue();
                        Console.WriteLine($"Atendendo cliente {clienteAtendido.Nome} (CPF: {clienteAtendido.CPF}), senha {clienteAtendido.Senha}");
                    }
                    else
                    {
                        Console.WriteLine("Fila de atendimento vazia, não há clientes para atender.");
                    }
                    break;

                case "4":
                    Console.WriteLine("Encerrando o programa.");
                    Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("Opção inválida. Tente novamente.");
                    break;
            }
        }
    }
}

class Cliente
{
    public string CPF { get; }
    public string Nome { get; }
    public int Senha { get; }

    public Cliente(string cpf, string nome, int senha)
    {
        CPF = cpf;
        Nome = nome;
        Senha = senha;
    }
}
